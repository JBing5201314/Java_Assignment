/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pms;

/**
 *
 * @author jiangbing
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Loading loading = new Loading();
        Login login = new Login();
        loading.setLocationRelativeTo(null);
        loading.setVisible(true);
        try {
            for (int i = 0; i <= 100; i++) {
                Thread.sleep(10);
                loading.loadingLabel.setText(Integer.toString(i) + "%");
                loading.loadingProgressBar.setValue(i);               
            if(i == 100){
                loading.setVisible(false);
                login.setLocationRelativeTo(null);
                login.setVisible(true);
            }
                
            }
        } catch (InterruptedException e) {

        }
    }

}
